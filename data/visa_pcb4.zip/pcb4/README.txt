Subset of the VisA dataset (Zou et al., ECCV 2022), (c) Amazon, released under CC BY 4.0.
Source: https://github.com/amazon-science/spot-diff
Changes: random subset (150 train normal, 100 test normal, 100 test anomaly), images resized to 448 px long side (JPEG), masks binarized.
